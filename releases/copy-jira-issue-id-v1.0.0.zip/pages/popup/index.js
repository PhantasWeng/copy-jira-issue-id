import { r as react, _ as _defineProperty, D as DEFAULT_LANGUAGE, t as translations, a as reactDom } from '../../chunks/translations-41e24eb3.js';

const CopyIcon = () => /*#__PURE__*/react.createElement("svg", {
  viewBox: "0 0 24 24",
  width: "15",
  height: "15",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, /*#__PURE__*/react.createElement("rect", {
  x: "9",
  y: "9",
  width: "13",
  height: "13",
  rx: "2",
  ry: "2"
}), /*#__PURE__*/react.createElement("path", {
  d: "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"
}));

const CheckIcon = () => /*#__PURE__*/react.createElement("svg", {
  viewBox: "0 0 24 24",
  width: "15",
  height: "15",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2.5",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, /*#__PURE__*/react.createElement("polyline", {
  points: "20 6 9 17 4 12"
}));

const SettingsIcon = () => /*#__PURE__*/react.createElement("svg", {
  viewBox: "0 0 24 24",
  width: "16",
  height: "16",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, /*#__PURE__*/react.createElement("circle", {
  cx: "12",
  cy: "12",
  r: "3"
}), /*#__PURE__*/react.createElement("path", {
  d: "M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"
}));

class App extends react.Component {
  constructor(props) {
    super(props);

    _defineProperty(this, "componentDidMount", () => {
      chrome.storage.sync.get('language', result => {
        const language = result.language || DEFAULT_LANGUAGE;
        this.setState({
          language
        });
        chrome.tabs.query({
          active: true,
          currentWindow: true
        }, tabs => {
          const url = tabs[0].url;
          const isJira = /atlassian\.net/.test(url);

          if (!isJira) {
            this.setState({
              isJira: false,
              loaded: true
            });
            return;
          }

          chrome.tabs.sendMessage(tabs[0].id, {
            action: 'getJiraIds'
          }, response => {
            if (chrome.runtime.lastError || !response) {
              this.setState({
                isJira: true,
                ids: [],
                loaded: true
              });
              return;
            }

            this.setState({
              isJira: true,
              ids: response.ids || [],
              loaded: true
            });
          });
        });
      });
    });

    _defineProperty(this, "typeBadgeClass", type => {
      return 'type-badge type-badge--' + (type || 'unknown').toLowerCase().replace(/[\s-]+/g, '-');
    });

    _defineProperty(this, "handleCopy", id => {
      navigator.clipboard.writeText(id).then(() => {
        this.setState({
          copiedId: id
        });
        setTimeout(() => {
          this.setState({
            copiedId: null
          });
        }, 600);
      });
    });

    _defineProperty(this, "handleOpenSettings", () => {
      chrome.runtime.openOptionsPage();
    });

    this.state = {
      isJira: null,
      ids: [],
      copiedId: null,
      language: DEFAULT_LANGUAGE,
      loaded: false
    };
  }

  render() {
    const t = translations[this.state.language];
    const {
      isJira,
      ids,
      copiedId,
      loaded
    } = this.state;

    const ContentBlock = () => {
      if (!loaded) return null;
      if (!isJira) return /*#__PURE__*/react.createElement("div", {
        className: "empty-state"
      }, t.notJiraPage);
      if (ids.length === 0) return /*#__PURE__*/react.createElement("div", {
        className: "empty-state"
      }, t.noIdsFound);
      return /*#__PURE__*/react.createElement("ul", {
        className: "id-list"
      }, ids.map(({
        id,
        type
      }) => /*#__PURE__*/react.createElement("li", {
        key: id,
        className: "id-row"
      }, /*#__PURE__*/react.createElement("span", {
        className: "id-info"
      }, /*#__PURE__*/react.createElement("span", {
        className: this.typeBadgeClass(type)
      }, type || '?'), /*#__PURE__*/react.createElement("span", {
        className: "id-text"
      }, id)), /*#__PURE__*/react.createElement("button", {
        className: `copy-btn${copiedId === id ? ' copy-btn--success' : ''}`,
        onClick: () => this.handleCopy(id),
        title: copiedId === id ? t.success : t.copyButton
      }, copiedId === id ? /*#__PURE__*/react.createElement(CheckIcon, null) : /*#__PURE__*/react.createElement(CopyIcon, null)))));
    };

    return /*#__PURE__*/react.createElement("div", {
      className: "container"
    }, /*#__PURE__*/react.createElement("div", {
      className: "header"
    }, /*#__PURE__*/react.createElement("span", {
      className: "header-title"
    }, t.title), /*#__PURE__*/react.createElement("button", {
      className: "settings-btn",
      onClick: this.handleOpenSettings,
      title: t.settings
    }, /*#__PURE__*/react.createElement(SettingsIcon, null))), /*#__PURE__*/react.createElement(ContentBlock, null));
  }

}

const root = document.querySelector('#root');
reactDom.render( /*#__PURE__*/react.createElement(App, null), root);
