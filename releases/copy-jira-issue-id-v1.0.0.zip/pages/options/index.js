import { r as react, _ as _defineProperty, D as DEFAULT_LANGUAGE, t as translations, a as reactDom } from '../../chunks/translations-41e24eb3.js';

const LogoIcon = () => /*#__PURE__*/react.createElement("svg", {
  viewBox: "0 0 24 24",
  width: "20",
  height: "20",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, /*#__PURE__*/react.createElement("rect", {
  x: "9",
  y: "9",
  width: "13",
  height: "13",
  rx: "2",
  ry: "2"
}), /*#__PURE__*/react.createElement("path", {
  d: "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"
}));

class App extends react.Component {
  constructor(props) {
    super(props);

    _defineProperty(this, "handleLanguageChange", e => {
      this.setState({
        language: e.target.value
      });
    });

    _defineProperty(this, "handleSave", () => {
      chrome.storage.sync.set({
        language: this.state.language
      }, () => {
        this.setState({
          saved: true
        });
        setTimeout(() => this.setState({
          saved: false
        }), 1500);
      });
    });

    this.state = {
      language: DEFAULT_LANGUAGE,
      saved: false
    };
  }

  componentDidMount() {
    chrome.storage.sync.get('language', result => {
      if (result.language) {
        this.setState({
          language: result.language
        });
      }
    });
  }

  render() {
    const t = translations[this.state.language];
    return /*#__PURE__*/react.createElement("div", {
      className: "options-container"
    }, /*#__PURE__*/react.createElement("div", {
      className: "options-header"
    }, /*#__PURE__*/react.createElement("div", {
      className: "options-logo"
    }, /*#__PURE__*/react.createElement(LogoIcon, null)), /*#__PURE__*/react.createElement("h1", {
      className: "options-title"
    }, t.settings)), /*#__PURE__*/react.createElement("div", {
      className: "options-card"
    }, /*#__PURE__*/react.createElement("div", {
      className: "options-section"
    }, /*#__PURE__*/react.createElement("label", {
      className: "options-label"
    }, "Language / \u8A9E\u8A00"), /*#__PURE__*/react.createElement("div", {
      className: "options-radio-group"
    }, /*#__PURE__*/react.createElement("label", {
      className: "options-radio-label"
    }, /*#__PURE__*/react.createElement("input", {
      type: "radio",
      name: "language",
      value: "en",
      checked: this.state.language === 'en',
      onChange: this.handleLanguageChange
    }), "English"), /*#__PURE__*/react.createElement("label", {
      className: "options-radio-label"
    }, /*#__PURE__*/react.createElement("input", {
      type: "radio",
      name: "language",
      value: "zh-TW",
      checked: this.state.language === 'zh-TW',
      onChange: this.handleLanguageChange
    }), "\u7E41\u9AD4\u4E2D\u6587")))), /*#__PURE__*/react.createElement("div", {
      className: "options-footer"
    }, /*#__PURE__*/react.createElement("button", {
      className: "save-btn",
      onClick: this.handleSave
    }, "Save"), this.state.saved && /*#__PURE__*/react.createElement("span", {
      className: "saved-feedback"
    }, "\u2713 Saved!")));
  }

}

const root = document.querySelector('#root');
reactDom.render( /*#__PURE__*/react.createElement(App, null), root);
